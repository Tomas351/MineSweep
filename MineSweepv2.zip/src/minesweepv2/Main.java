package minesweepv2;


public class Main {

    public static void main(String[] args) {
        Game game = ConsoleGame.getInstance();
        game.run();
    }
    
}
